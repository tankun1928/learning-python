n = int(input("Number of items in a list: "))
mylist = input("Enter %d integers for the list: " % n).split()
mylist = list(map(int, mylist))
x = int(input("Enter x: "))

isDone = False

for i in range(len(mylist)):
    if mylist[i] >= x:
        print("Insert at", i)
        mylist.insert(i, x)
        isDone = True
        break

if not isDone:
    print("Insert at", len(mylist))
    mylist.append(x)


print("Final list:",end = " ")

for item in mylist:
    print(item,end = " ")