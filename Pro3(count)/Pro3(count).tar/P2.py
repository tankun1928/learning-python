n = int(input("Enter n: "))

for n in range(0, n):
    if n == 0:
     print("!", end="")
    elif n%5 == 0:
     print("!", end="")
    else:
     print("*", end="") 


